#include "esp_log.h"
#include "u8g2.h"
#include <stdbool.h>
#include <stdbool.h>
#include <stdio.h>
#include <sys/_intsup.h>
#include "temp_graph.h"
#include <time.h>
#include "esp_log.h"
#include <string.h>,
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#define MAX_SIZE_ARRAY_FROM_MAIN 122

static const char *ARRAY = "TEMPERATURE_ARRAY_FROM_MAIN";

int set_value_temp_graph=0;
int x_location=5;

float temperature_array_for_temp_graph[MAX_SIZE_ARRAY_FROM_MAIN];

static int count_array_number_array_func=0;
//bool median_calculute= false;



void get_array_from_main(float temperature_array_from_main[]){
		
			temperature_array_for_temp_graph[count_array_number_array_func] = temperature_array_from_main[count_array_number_array_func];
			ESP_LOGW(ARRAY,"array parameter:%.2lf-",temperature_array_from_main[count_array_number_array_func]);
			if(temperature_array_for_temp_graph[count_array_number_array_func]>0){
				count_array_number_array_func++;
				count_array_number_array_func=count_array_number_array_func % MAX_SIZE_ARRAY_FROM_MAIN +1 ;
				vTaskDelay(pdMS_TO_TICKS(500));			
		}		
}
	

void temp_graph_(u8g2_t *u8g2, bool  show_temp_screen_flag){
	
	static const uint8_t image_ButtonRightSmall_bits[] = {0x01,0x03,0x07,0x03,0x01};
	u8g2_SetBitmapMode(u8g2, 1);
	u8g2_SetFontMode(u8g2, 1);
	u8g2_DrawLine(u8g2, 0, 0, 0, 63);
	u8g2_DrawLine(u8g2, 0, 63, 127, 63);	
	u8g2_DrawXBM(u8g2, 1, 30, 3, 5, image_ButtonRightSmall_bits);
	
	
	for(int i=-0 ; i< count_array_number_array_func + 1 ; i++){
		if(temperature_array_for_temp_graph[i]>0){ 
    		set_value_temp_graph = 26 - temperature_array_for_temp_graph[i];
    	
			if(set_value_temp_graph>0){
				set_value_temp_graph+=26;
				u8g2_DrawLine(u8g2,x_location,set_value_temp_graph,x_location,set_value_temp_graph);			
			}
			if(set_value_temp_graph<0){
				set_value_temp_graph+=26;
				u8g2_DrawLine(u8g2,x_location,set_value_temp_graph,x_location,set_value_temp_graph);		
				}				
			if(set_value_temp_graph==0){
				set_value_temp_graph=26;
				u8g2_DrawLine(u8g2,x_location,set_value_temp_graph,x_location,set_value_temp_graph);		
			}
			x_location++;
			//satirin basina tekrar gidilir 
			if(x_location==129){
				x_location=5;
				u8g2_ClearBuffer(u8g2);
			}
			u8g2_SetFont(u8g2, u8g2_font_ncenB08_tr);
			srand((unsigned int)time(NULL));	
			if(show_temp_screen_flag){
				u8g2_SendBuffer(u8g2); 
			}
		}
	}
}
