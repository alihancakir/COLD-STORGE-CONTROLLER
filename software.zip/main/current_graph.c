#include "u8g2.h"
#include <stdio.h>
#include <sys/_intsup.h>
#include "current_graph.h"
#include <time.h>

//int set_value_current_graph=0;
static int  x_location=5;
int random_number=23;

void current_graph_(u8g2_t *u8g2, int current_from_main){
	
	static const uint8_t image_ButtonRightSmall_bits[] = {0x01,0x03,0x07,0x03,0x01};
	//u8g2_ClearBuffer(u8g2); 
	u8g2_SetBitmapMode(u8g2, 1);
	u8g2_SetFontMode(u8g2, 1);
	u8g2_DrawLine(u8g2, 0, 0, 0, 63);
	u8g2_DrawLine(u8g2, 0, 63, 127, 63);
	
	u8g2_DrawXBM(u8g2, 1, 30, 3, 5, image_ButtonRightSmall_bits);
	
	
	
	int event_for_referans_line= 32-(current_from_main*20);
	
	if(event_for_referans_line<0 ){
		event_for_referans_line+=38;
		u8g2_DrawLine(u8g2,x_location,event_for_referans_line,x_location,event_for_referans_line);		
	
	}
	if(event_for_referans_line>0 ){
		event_for_referans_line+=48;
		u8g2_DrawLine(u8g2,x_location,event_for_referans_line,x_location,event_for_referans_line);
	}
	if(event_for_referans_line==0){
		event_for_referans_line+=32;
		u8g2_DrawLine(u8g2,x_location,event_for_referans_line,x_location,event_for_referans_line);
	}
	
	
	
	
	
	
	if(x_location==126){
		x_location=5;
		u8g2_ClearBuffer(u8g2);
	}
	
	x_location++;
	u8g2_SetFont(u8g2, u8g2_font_ncenB08_tr);	 
	u8g2_SendBuffer(u8g2);
	srand((unsigned int)time(NULL));
}