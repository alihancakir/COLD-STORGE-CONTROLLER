#include "u8g2.h"
#include <stdbool.h>

#ifndef MAIN_TEMP_GRAPH_H_
#define MAIN_TEMP_GRAPH_H_

void temp_graph_(u8g2_t *u8g2, bool  show_temp_screen_flag);
void get_array_from_main(float temperature_array_from_main[]);

#endif 
