

#ifndef MAIN_I2C_CONFIG_H_
#define MAIN_I2C_CONFIG_H_


#include "driver/i2c.h"
#include "driver/i2c_master.h"		

#include "u8g2.h"



uint8_t idf_esp32_byte_cb(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int, void *arg_ptr);
uint8_t idf_esp32_gpio_and_delay_cb(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int, void *arg_ptr);
void i2c_master_init();


#endif 
