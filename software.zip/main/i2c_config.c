#include <stdint.h>
#include <stdio.h>
#include "driver/i2c.h"
#include "driver/i2c_master.h"		
#include "freertos/FreeRTOS.h"
#include "freertos/projdefs.h"
#include "freertos/task.h"
#include "hal/gpio_types.h"
#include "u8g2.h"
#include "esp_log.h"
#include <time.h>
#include "i2c_config.h"


#define I2C_MASTER_SDA_IO 21		
#define I2C_MASTER_SCL_IO 22
#define I2C_CLK_SPEED 400*1000
#define I2C_MASTER_NUM I2C_NUM_0      // I2C port number for master
#define I2C_MASTER_TX_BUF_DISABLE 0   // I2C master doesn't need buffer
#define I2C_MASTER_RX_BUF_DISABLE 0   // I2C master doesn't need buffer
#define I2C_ADDRESS_OLED 0x3C

static const char* TAG = "I2C";


 i2c_cmd_handle_t handle_i2c;

uint8_t idf_esp32_byte_cb(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int, void *arg_ptr)
{
	uint8_t *data = (uint8_t *)arg_ptr;
	uint8_t I2C_ADDRESS;
	ESP_LOGV(TAG,"AMK");
  switch(msg)
  {
    case U8X8_MSG_BYTE_SEND:
   	
    	data = (uint8_t *)arg_ptr;
		while( arg_int > 0 ) {
		   ESP_ERROR_CHECK(i2c_master_write_byte(handle_i2c, *data, 1));
		   data++;
		   arg_int--;
		}
      break;
      
    case U8X8_MSG_BYTE_INIT:

      break;
      
    case U8X8_MSG_BYTE_SET_DC:
      break;
      
    case U8X8_MSG_BYTE_START_TRANSFER:
		// Start I2C transfer
		I2C_ADDRESS = u8x8_GetI2CAddress(u8x8);
        handle_i2c = i2c_cmd_link_create();
        ESP_LOGD(TAG, "Start I2C transfer to %02X.", I2C_ADDRESS>>1);
        i2c_master_start(handle_i2c);
        i2c_master_write_byte(handle_i2c, I2C_ADDRESS | I2C_MASTER_WRITE, true);
        //return i2c_master_cmd_begin(I2C_MASTER_NUM, cmd, pdMS_TO_TICKS(1000));
      break;
      
    case U8X8_MSG_BYTE_END_TRANSFER:
		// End I2C transfer
	    i2c_master_stop(handle_i2c);
	    i2c_master_cmd_begin(I2C_MASTER_NUM, handle_i2c, pdMS_TO_TICKS(1000));
	    i2c_cmd_link_delete(handle_i2c);
      break;
      
    default:
      return 0;
  }
  return 1;
}


uint8_t idf_esp32_gpio_and_delay_cb(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int, void *arg_ptr)
{
  switch(msg)
  {
    case U8X8_MSG_DELAY_NANO:			// delay arg_int * 1 nano second
      break;    
    case U8X8_MSG_DELAY_100NANO:		// delay arg_int * 100 nano seconds
      break;
    case U8X8_MSG_DELAY_10MICRO:		// delay arg_int * 10 micro seconds
      break;
    case U8X8_MSG_DELAY_MILLI:			// delay arg_int * 1 milli second
    	vTaskDelay(1 / portTICK_PERIOD_MS);
      break;
    case U8X8_MSG_DELAY_I2C:				// arg_int is the I2C speed in 100KHz, e.g. 4 = 400 KHz
      break;							// arg_int=1: delay by 5us, arg_int = 4: delay by 1.25us

    default:
      u8x8_SetGPIOResult(u8x8, 1);			// default return value
      break;
  }
  return 1;
}

void i2c_master_init(){
	int i2c_master_port = 0;
		i2c_config_t conf = {
	    .mode = I2C_MODE_MASTER,
	    .sda_io_num = I2C_MASTER_SDA_IO,         // select SDA GPIO specific to your project
	    .sda_pullup_en = GPIO_PULLUP_ENABLE,
	    .scl_io_num = I2C_MASTER_SCL_IO,         // select SCL GPIO specific to your project
	    .scl_pullup_en = GPIO_PULLUP_ENABLE,
	    .master.clk_speed = I2C_CLK_SPEED,  	 // select frequency specific to your project
	    .clk_flags = 0,                          // optional; you can use I2C_SCLK_SRC_FLAG_* flags to choose i2c source clock here
	};
	
	
	i2c_param_config(i2c_master_port, &conf);
	i2c_driver_install(i2c_master_port, conf.mode, I2C_MASTER_RX_BUF_DISABLE, I2C_MASTER_TX_BUF_DISABLE, 0);
	
}	
	