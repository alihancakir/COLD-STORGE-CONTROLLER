#include "esp_log.h"
#include "esp_adc_cal.h"
#include "adc_config.h"
#include <stdio.h>
#include <stdlib.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/adc.h"


#if CONFIG_IDF_TARGET_ESP32
#define ADC1_EXAMPLE_CHAN0          ADC1_CHANNEL_5
#define ADC2_EXAMPLE_CHAN0          ADC2_CHANNEL_7
static const char *TAG_CH[2][10] = {{"ADC1_CH5"}, {"ADC2_CH7"}};
#else
#define ADC1_EXAMPLE_CHAN0          ADC1_CHANNEL_5
#define ADC2_EXAMPLE_CHAN0          ADC2_CHANNEL_7
static const char *TAG_CH[2][10] = {{"ADC1_CH5"}, {"ADC2_CH7"}};
#endif

#define ADC_EXAMPLE_ATTEN           ADC_ATTEN_DB_11

#if CONFIG_IDF_TARGET_ESP32
#define ADC_EXAMPLE_CALI_SCHEME     ESP_ADC_CAL_VAL_EFUSE_VREF
#elif CONFIG_IDF_TARGET_ESP32S2
#define ADC_EXAMPLE_CALI_SCHEME     ESP_ADC_CAL_VAL_EFUSE_TP
#elif CONFIG_IDF_TARGET_ESP32C3
#define ADC_EXAMPLE_CALI_SCHEME     ESP_ADC_CAL_VAL_EFUSE_TP
#elif CONFIG_IDF_TARGET_ESP32S3
#define ADC_EXAMPLE_CALI_SCHEME     ESP_ADC_CAL_VAL_EFUSE_TP_FIT
#endif

static int adc_raw[2][10];
static const char *TAG = "ADC SINGLE";

static esp_adc_cal_characteristics_t adc1_chars;
static esp_adc_cal_characteristics_t adc2_chars;

esp_err_t ret = ESP_OK;

float voltage2 = 0;
int res = 0;
int res_readed = 0;  
int j = 0;
float temperature = 0;
float voltage = 0; 

// NTC10K DATASHEET VALUES
    int res_ntc[] = {26834, 25395, 24042, 22770, 21573, 20446, 19376, 18378, 17437, 16550,
                     15714, 14925, 14180, 13478, 12814, 12182, 11590, 11030, 10501,
                     10000, 9526, 9078, 8653, 8251, 7866, 7505, 7163, 6838,
                      6530, 6238, 5960, 5697, 5447, 5207, 4981, 4766, 4561};
                     
    float temp[] = {3.9, 5.0, 6.1, 7.2, 8.3, 9.4, 10.6, 11.7, 12.8, 13.9,
                    15.0, 16.1, 17.2, 18.3, 19.4, 20.6, 21.7, 22.8, 23.9,
                    25.0, 26.1, 27.2, 28.3, 29.4, 30.6, 31.7, 32.8, 33.9,
                    35.0, 36.1, 37.2, 38.3, 39.4, 40.6, 41.7, 42.8, 43.9};


static bool cali_enable = false; // Global olarak kalibrasyon durumunu saklıyoruz.

 bool adc_calibration_init(void) {
    if (cali_enable) {
        return true; // Zaten kalibrasyon yapılmışsa, tekrar yapmaya gerek yok.
    }

    esp_err_t ret = esp_adc_cal_check_efuse(ADC_EXAMPLE_CALI_SCHEME);
    if (ret == ESP_ERR_NOT_SUPPORTED) {
        ESP_LOGW(TAG_CH[0][0], "Calibration scheme not supported");
    } else if (ret == ESP_ERR_INVALID_VERSION) {
        ESP_LOGW(TAG_CH[0][0], "eFuse not burnt");
    } else if (ret == ESP_OK) {
        cali_enable = true;
        esp_adc_cal_characterize(ADC_UNIT_1, ADC_EXAMPLE_ATTEN, ADC_WIDTH_BIT_12, 0, &adc1_chars);
        esp_adc_cal_characterize(ADC_UNIT_2, ADC_EXAMPLE_ATTEN, ADC_WIDTH_BIT_12, 0, &adc2_chars);
    } else {
        ESP_LOGE(TAG_CH[0][0], "Invalid argument: %d", ret); // Hata kodunu logluyoruz.
    }

    return cali_enable;
}

void adc_init(void) {
    ESP_ERROR_CHECK(adc1_config_width(ADC_WIDTH_BIT_12));
    ESP_ERROR_CHECK(adc1_config_channel_atten(ADC1_EXAMPLE_CHAN0, ADC_EXAMPLE_ATTEN));
    ESP_ERROR_CHECK(adc2_config_channel_atten(ADC2_EXAMPLE_CHAN0, ADC_EXAMPLE_ATTEN));
}

float get_temperature(void) {
	
    if (!adc_calibration_init()) {
        ESP_LOGE(TAG_CH[0][0], "ADC calibration failed");
        return -1; // Eğer kalibrasyon yapılamazsa hata döndürüyoruz.
    }

 
	
    adc_raw[0][0] = adc1_get_raw(ADC1_EXAMPLE_CHAN0);
    voltage2 = esp_adc_cal_raw_to_voltage(adc_raw[0][0], &adc1_chars) / 1000.0; // Voltajı hesaplıyoruz
    res = (33000 / voltage2) - 10000; // Direnç hesaplaması

	 for (j = 0; j < 35; j++) {		
        int result = res - res_ntc[j];
        if (result <= 50 && result >= -50) {
            temperature = temp[j];
            break; // Uygun sıcaklık bulunduğunda döngüden çıkıyoruz
        }
    }
	
   
    return temperature;
}

float get_current(void) {
    /*if (!adc_calibration_init()) {
        ESP_LOGE(TAG_CH[1][0], "ADC calibration failed");
        return -1; // Eğer kalibrasyon yapılamazsa hata döndürüyoruz.
    }*/

    
    do {
            ret = adc2_get_raw(ADC2_EXAMPLE_CHAN0, ADC_WIDTH_BIT_DEFAULT, &adc_raw[1][0]);
        } while (ret == ESP_ERR_INVALID_STATE);
        ESP_ERROR_CHECK(ret);

        //ESP_LOGI(TAG_CH[1][0], "raw  data: %d", adc_raw[1][0]);
        if (cali_enable) {
            voltage = esp_adc_cal_raw_to_voltage(adc_raw[1][0], &adc2_chars);           
            voltage/=1000;            
            //ESP_LOGI(TAG_CH[1][0], "CURRENT_SENSOR: %.2lf V ",voltage);
    		
		}
		return voltage;
	}