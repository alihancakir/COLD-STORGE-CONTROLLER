#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/projdefs.h"
#include "freertos/task.h"
#include "freertos/queue.h"

#include "driver/adc.h"
#include "esp_adc_cal.h"
#include "adc_config.h"

#include "driver/i2c.h"
#include "driver/i2c_master.h"
#include <time.h>
#include "i2c_config.h"

#include "driver/gpio.h"
#include "hal/gpio_types.h"
#include "hardware.h"

#include "u8g2.h"

#include "menu_graph.h"

#include "temp_graph.h"

#include "current_graph.h"

#define I2C_CLK_SPEED 400*1000
#define I2C_MASTER_NUM I2C_NUM_0      // I2C port number for master
#define I2C_MASTER_TX_BUF_DISABLE 0   // I2C master doesn't need buffer
#define I2C_MASTER_RX_BUF_DISABLE 0   // I2C master doesn't need buffer
#define I2C_ADDRESS_OLED 0x3C

#define MAX_SIZE_ARRAY 122  

u8g2_t u8g2;

TaskHandle_t get_temperature_task_Handle = NULL;
QueueHandle_t queue_temperature_handle;

TaskHandle_t get_current_task_Handle = NULL;
QueueHandle_t queue_current_handle;

TaskHandle_t menu_graph_task_Handle = NULL;

TaskHandle_t button_1_event_task_Handle = NULL;
TaskHandle_t button_2_event_task_Handle = NULL;
TaskHandle_t button_3_event_task_Handle = NULL;
TaskHandle_t button_4_event_task_Handle = NULL;

TaskHandle_t add_temp_to_array_for_graph_task_Handle = NULL;

static const char *get_temperature_task_func = "TEMPERATURE_GET_TASK";
static const char *get_current_task_func = "CURRENT_GET_TASK";
static const char *TASK="button_1_event_task";
static const char *COUNT_INDEX_MAIN="INDEX_FOR_ARRAY_TEMP";

float temperature_value=0;
float current_value=0;

bool event_any_button_pressed= false;

bool check_button_1_pressed= false;
bool check_button_2_pressed= false;
bool check_button_3_pressed= false;

bool button_3_active = false;

bool show_temp_screen_flag_main= false;

float array_for_temperature[MAX_SIZE_ARRAY];

int count_array_index_number=0;

//temperature value getting here
void get_temperature_task(void *arg)
{
	queue_temperature_handle= xQueueCreate(10, sizeof(float));
	if( queue_temperature_handle == 0 ){
    ESP_LOGW("TEMPERATURE_GET_TASK","FAILED TO CREATE queue_temperature_handle "); 
 	}
 	while(1){
 	
 	temperature_value =  get_temperature();	
	ESP_LOGI(get_temperature_task_func,"TEMPERATURE:%.2f",temperature_value);	 		
 	
	if (xQueueSend(queue_temperature_handle, &temperature_value, (TickType_t)500) == pdPASS) {
            ESP_LOGI("TEMPERATURE_GET_TASK", "TEMPERATURE VALUE IS SENT QUEUE");
        } 
    else {
            ESP_LOGW("TEMPERATURE_GET_TASK", "queue_temperature_handle IS FULL.");
        }
        vTaskDelay(pdMS_TO_TICKS(500));
 	}
}

//current value getting here
void get_current_task(void *arg)
{
	queue_current_handle= xQueueCreate(10, sizeof(float));
	if( queue_current_handle == 0 ){
    ESP_LOGW("CURRENT_GET_TASK","FAILED TO CREATE queue_current_handle "); 
 	}
 	while(1){
	
    current_value= get_current();	
	ESP_LOGI(get_current_task_func,"CURRENT:%.2f",current_value);	 		
 	
	if (xQueueSend(queue_current_handle, &current_value, (TickType_t)500) == pdPASS) {
            ESP_LOGI("CURRENT_GET_TASK", "CURRENT VALUE IS SENT TO QUEUE");
        } 
    else {
            ESP_LOGW("CURRENT_GET_TASK", "queue_current_handle IS FULL.");
        }
        vTaskDelay(pdMS_TO_TICKS(500));
 	}
}

//menu graph runing here
/*
void menu_graph_task(void *arg){
		if(event_any_button_pressed==false){
			while(1){
		
				xQueueReceive(queue_temperature_handle ,  &temperature_value , (TickType_t)500);								
				menu_graph(&u8g2,temperature_value);			
				
				
				
		
	
				//xQueueReceive(queue_current_handle ,  &current_value , (TickType_t)500);
		
				
		
		}		
	}
	
}
*/



void add_temp_to_array_for_graph_task(void *arg){
	while(1){
		xQueueReceive(queue_temperature_handle ,  &temperature_value , (TickType_t)500);
		if(temperature_value>0){
			ESP_LOGE(COUNT_INDEX_MAIN,"count_array_index_number: %d",count_array_index_number);
			array_for_temperature[count_array_index_number]=temperature_value;		
			get_array_from_main(array_for_temperature);
			temp_graph_(&u8g2,show_temp_screen_flag_main);
			count_array_index_number++;
			count_array_index_number= count_array_index_number % 30;
		}		
	}
}


void button_1_event_task(void*arg){
	while(1){		
		if(!button_3_active){	
		if(gpio_get_level(BUTTON_1)==1||check_button_1_pressed== true){
			show_temp_screen_flag_main=true;					
			event_any_button_pressed= true;
			if(check_button_2_pressed==false){
			check_button_1_pressed= true;					
		
	}	
	}		
	}
	vTaskDelay(pdMS_TO_TICKS(100));
}
}

void button_2_event_task(void*arg){
	while(1){
		
	if(gpio_get_level(BUTTON_2)==1 || check_button_2_pressed== true){
		check_button_1_pressed=false;
		check_button_2_pressed= true;		
		current_graph_(&u8g2,current_value);		
		event_any_button_pressed= true;		
	}
	vTaskDelay(pdMS_TO_TICKS(100));
}
}


void button_3_event_task(void*arg){
	while (1) {
        if (gpio_get_level(BUTTON_3) == 1) {
            button_3_active = true; // BUTTON_4 aktif
            show_temp_screen_flag_main=false;
            u8g2_ClearBuffer(&u8g2);
			u8g2_SendBuffer(&u8g2);
            //ESP_LOGW("BUTTON_3_CONTROL", "BUTTON_3 PRESSED: Blocking tasks");
        } else {
            button_3_active = false; // BUTTON_4 pasif
            //ESP_LOGW("BUTTON_3_CONTROL", "BUTTON_3 RELEASED: Tasks operational");
        }
        vTaskDelay(pdMS_TO_TICKS(100)); // Debounce ve CPU yükünü azaltma
    }
	 
}	


/*
void button_4_event_task(void*arg){
		
			if(gpio_get_level(BUTTON_4)==1){
				u8g2_ClearBuffer(&u8g2);
				u8g2_SendBuffer(&u8g2);
				check_button_1_pressed= false;
				check_button_2_pressed= false;
				event_any_button_pressed= false;
				show_temp_screen_flag_main=false;
				
					
			}
			vTaskDelay(pdMS_TO_TICKS(50));
		}
		

*/
void app_main(void){
	
 	button_config();	
	bool cali_enable = adc_calibration_init();
	adc_init();	
	uint8_t idf_esp32_byte_cb(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int, void *arg_ptr);
	uint8_t idf_esp32_gpio_and_delay_cb(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int, void *arg_ptr);	
	i2c_master_init();
	u8g2_SetI2CAddress(&u8g2, I2C_ADDRESS_OLED << 1);
	u8g2_Setup_sh1106_i2c_128x64_noname_f(&u8g2, U8G2_R0,  idf_esp32_byte_cb,  idf_esp32_gpio_and_delay_cb);
	u8g2_InitDisplay(&u8g2);
	u8g2_SetPowerSave(&u8g2, 0); 
	u8g2_SetFont(&u8g2, u8g2_font_ncenB08_tr);
	u8g2_ClearBuffer(&u8g2);
	u8g2_SendBuffer(&u8g2);


xTaskCreate
		(//also send to queue
			get_temperature_task,
		    "get_temperature_task",
	        4096,
	        NULL,
	        5, 
	        &get_temperature_task_Handle
	    );

xTaskCreate
		(//also send to queue
			get_current_task,
		    "get_current_task",
	        4096,
	        NULL,
	        5, 
	        &get_current_task_Handle
	    );
	    
xTaskCreate
		(
			add_temp_to_array_for_graph_task,
		    "add_temp_to_array_for_graph_task",
	        4096,
	        NULL,
	        8, 
	        &add_temp_to_array_for_graph_task_Handle
	    );	    
	    
	    
	    
	    
	    
	    
	    
	    
/*
xTaskCreate
		(
			menu_graph_task,
		    "menu_graph_task",
	        4096,
	        NULL,
	        10, 
	        &menu_graph_task_Handle
	    );
*/	    
xTaskCreate
		(
			button_1_event_task,
		    "button_1_event_task",
	        4096,
	        NULL,
	        7, 
	        &button_2_event_task_Handle
	    );	    

xTaskCreate
		(
			button_2_event_task,
		    "button_2_event_task",
	        4096,
	        NULL,
	        8, 
	        &button_2_event_task_Handle
	    );	    
   
xTaskCreate
		(
			button_3_event_task,
		    "button_3_event_task",
	        4096,
	        NULL,
	        8, 
	        &button_3_event_task_Handle
	    );	
 /*
xTaskCreate
		(
			button_4_event_task,
		    "button_4_event_task",
	        4096,
	        NULL,
	        10, 
	        &button_4_event_task_Handle
	    );	
*/		           
}