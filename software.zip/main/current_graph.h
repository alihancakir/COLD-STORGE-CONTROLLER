#include "u8g2.h"


#ifndef MAIN_CURRENT_GRAPH_H_
#define MAIN_CURRENT_GRAPH_H_

void current_graph_(u8g2_t *u8g2, int current_from_main);


#endif /* MAIN_CURRENT_GRAPH_H_ */
