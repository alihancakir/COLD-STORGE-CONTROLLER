#include "driver/gpio.h"
#include "hal/gpio_types.h"

#include "hardware.h"

void button_config(void){
	
	gpio_set_direction(BUTTON_1, GPIO_MODE_INPUT);
    gpio_set_pull_mode(BUTTON_1, GPIO_PULLUP_ONLY); 
    
    gpio_set_direction(BUTTON_2, GPIO_MODE_INPUT);
    gpio_set_pull_mode(BUTTON_2, GPIO_PULLUP_ONLY); 
    
    gpio_set_direction(BUTTON_3, GPIO_MODE_INPUT);
    gpio_set_pull_mode(BUTTON_3, GPIO_PULLUP_ONLY); 
    
    gpio_set_direction(BUTTON_4, GPIO_MODE_INPUT);
    gpio_set_pull_mode(BUTTON_4, GPIO_PULLUP_ONLY); 
    
    gpio_set_direction(DIGITAL_INPUT, GPIO_MODE_INPUT);
    //gpio_set_pull_mode(DIGITAL_INPUT, GPIO_PULLUP_ONLY); 
    
    gpio_set_direction(RELAY_OUTPUT, GPIO_MODE_OUTPUT);
    gpio_set_direction(PWM_OUTPUT, GPIO_MODE_OUTPUT);

}