
#ifndef MAIN_HARDWARE_H_
#define MAIN_HARDWARE_H_

											//SCHEMATIC NAME,	PIN NUMBER,	  	IO NUMBER
#define BUTTON_1 	 	  GPIO_NUM_26  		//USER_BUTTON_4,		11,				26
#define BUTTON_2 	 	  GPIO_NUM_25  		//USER_BUTTON_3,		10,				25
#define BUTTON_3 	 	  GPIO_NUM_35  		//USER_BUTTON_2,		7,				35
#define BUTTON_4 	 	  GPIO_NUM_34  		//USER_BUTTON_1,		6,				34

#define RELAY_OUTPUT 	  GPIO_NUM_2  		//MCU_RELAY,			24,				2
#define PWM_OUTPUT 	 	  GPIO_NUM_12  		//MCU_PWM,				14,				12

#define DIGITAL_INPUT 	  GPIO_NUM_23  		//MCU_5_24V,			37,				23

#define I2C_MASTER_SDA_IO GPIO_NUM_21		//MCU_SDA,				33,				21
#define I2C_MASTER_SCL_IO GPIO_NUM_22		//MCU_SCL,				36,				22

void button_config(void);

#endif /* MAIN_HARDWARE_H_ */
