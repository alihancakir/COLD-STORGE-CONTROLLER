#include "u8g2.h"

#ifndef MAIN_MENU_GRAPH_H_
#define MAIN_MENU_GRAPH_H_

void menu_graph(u8g2_t *u8g2, float temperature_main);


#endif 

