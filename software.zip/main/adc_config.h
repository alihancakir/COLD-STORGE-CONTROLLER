#ifndef MAIN_ADC_CONFIG_H_
#define MAIN_ADC_CONFIG_H_

#include "esp_adc_cal.h"

bool adc_calibration_init(void);
void adc_init(void);
float get_temperature(void);
float get_current(void);

#endif 